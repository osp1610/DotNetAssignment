﻿namespace Properties
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter The isbn of Book");
            string isbn = Console.ReadLine();

            Console.WriteLine("Enter Name of book");
            string bookName = Console.ReadLine();

            Console.WriteLine("Enter Auther of book");
            string bookAuther = Console.ReadLine();

            Console.WriteLine("Enter Qty of book");
            int bookQty = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Price of Book");
            int bookPrice = Convert.ToInt32(Console.ReadLine());

            BookStore bookStore = new BookStore(isbn, bookName, bookAuther, bookQty, bookPrice);

            bookStore.Display();
        }
    }
}