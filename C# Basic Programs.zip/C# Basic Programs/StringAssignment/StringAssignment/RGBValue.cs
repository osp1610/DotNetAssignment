﻿namespace StringAssignment
{
    internal class RGBValue
    {
       public static void rgbVal()
        {
            Console.WriteLine("Enter the value of red, green, blue:");
            int r = Convert.ToInt32(Console.ReadLine());
            int g = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            if (r == 0 && g == 0 && b != 0)
            {
                Console.WriteLine("Bluish");
            }
            else if (r != 0 && g == 0 && b == 0)
            {
                Console.WriteLine("Reddish");
            }
            else if (r == 0 && g != 0 && b == 0)
            {
                Console.WriteLine("Greenish");
            }   
            else
            {
                Console.WriteLine("runtime error");
            }
        }

    }
}