﻿namespace CSharpPrograms
{
    internal class Palindrome
    {
        public static void PalindromeOrNot()
        {
            Console.WriteLine("Enter a Word to check it is palindrome or not:");
            String word=Console.ReadLine();
            String temp = word;
            String rev = "";
            int len = word.Length - 1;
            while (len >= 0)
            {
                rev += word[len];
                len--;
            }
            if (rev.Equals(temp))
            {
                Console.WriteLine("String is Palindrome");
            }
            else
            {
                Console.WriteLine("String is not Palindrome");
            }

        }
    }
}