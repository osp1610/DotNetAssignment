﻿namespace CollectiionAssignment
{
    internal class sortList
    {
       static List<int> list = new List<int>();
        public static void sortlist()
        {
            int no;
            Console.WriteLine("Enter a 10 Nos to sort in ascending order:");
            for (int i = 0; i < 10; i++)
            {
                no=Convert.ToInt32(Console.ReadLine());
                list.Add(no);
            }
            Console.WriteLine("Sorted list");
            list.Sort();
            for(int i = 0; i < list.Count; i++)
            {
                Console.WriteLine(list[i]);
            }
        }
    }
}