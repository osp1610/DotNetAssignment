﻿namespace CSharpPrograms
{
    internal class MultiplicationOfNo
    {
       public static void MultiplicationUpTo20()
        {
            Console.WriteLine("Enter a No:");
            String No = Console.ReadLine();
            int no = Convert.ToInt32(No);
            for(int i = 1; i <= 20; i++)
            {
                int result = i * no;
                Console.WriteLine(result);
            }

        }
    }
}