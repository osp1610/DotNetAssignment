﻿namespace CSharpPrograms
{
    internal class CompareWord
    {
        public static void compareTwoWords()
        {
            Console.WriteLine("Enter a First Word:");
            String firstword=Console.ReadLine();
            Console.WriteLine("Enter a Second Word:");
            String Secondword = Console.ReadLine();
            if (firstword.Equals(Secondword))
            {
                Console.WriteLine("Two Words are Equal");
            }
            else
            {
                Console.WriteLine("Two Words Are Not Equal");
            }
        }
    }
}