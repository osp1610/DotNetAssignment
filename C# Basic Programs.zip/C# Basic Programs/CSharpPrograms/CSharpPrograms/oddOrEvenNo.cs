﻿namespace CSharpPrograms
{
    internal class oddOrEvenNo
    {
        public static void oddevenNo()
        {
            String Number;
            int no;
            Console.WriteLine("Enter a Number to check it is odd or even");
            Number = Console.ReadLine();
            no=Convert.ToInt32(Number);
            if (no % 2 == 0)
            {
                Console.WriteLine(no + " is Even Number");
            }
            else
            {
                Console.WriteLine(no + " is Odd Number");
            }

        }
    }
}