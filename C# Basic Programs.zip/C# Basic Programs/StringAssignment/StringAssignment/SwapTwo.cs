﻿namespace StringAssignment
{
    internal class SwapTwo
    {
       public static void swapping()
        {
            Console.WriteLine("Enter Two numbers for swapping");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            a = a+b;
            b = a-b;
            a = a-b;
            Console.WriteLine("numbers after swapping");
            Console.Write(a);
            Console.WriteLine(" " + b);
        }

    }
}