﻿namespace StringAssignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //StringOperations.stringOperations();
            //SwapTwo.swapping();
            // EggsCount.Eggs();
            //leapYear.leapYearorNot();
            // RGBValue.rgbVal();
            Shopkeeper.ProductSells();
        }

    }
}