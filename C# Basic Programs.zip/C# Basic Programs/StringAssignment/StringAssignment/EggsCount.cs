﻿namespace StringAssignment
{
    internal class EggsCount
    {
       public static void Eggs()
        {
            Console.WriteLine("Enter Number Of Eggs");
            int no = Convert.ToInt32(Console.ReadLine());
            int grossEgg = no / 144;
            int k = no % 144;
            int dozenEgg = k / 12;
            int leftEggs = no % 12;
            Console.WriteLine("Your number of eggs is {0} Gross\n{1} Dozen\n{2} Left", grossEgg, dozenEgg, leftEggs);
        }

    }
}