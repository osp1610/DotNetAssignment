﻿using System.Collections;

namespace CollectiionAssignment

{
    internal class arraylistStudent
    {
        static ArrayList students = new ArrayList();
        static string stdNames;
        static int count;
        public static void arrayListForStudent()
        {
            Console.WriteLine("Enter a No of Students name you want to enter:");
            count= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a "+count+ " Students Name to display them in descending order:");
            for(int i = 0; i < count; i++)
            {
                stdNames = Console.ReadLine();
                students.Add(stdNames);
            }
            students.Sort();
            students.Reverse();

            Console.WriteLine("Sorted name list:");
            for(int i=0; i < students.Count; i++)
            {
                Console.WriteLine(students[i]);
            }

        }
    }
}