﻿namespace CSharpPrograms
{
    internal class LargerFromThree
    {
       public static void LargestNo()
        {
            int num1, num2, num3;
            Console.Write("Input the 1st number :");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input the  2nd number :");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input the 3rd  number :");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2)
            {
                if (num1 > num3)
                {
                    Console.Write(num1+" Number is the greatest among three. \n\n");
                }
                else
                {
                    Console.Write(num3+" Number is the greatest among three. \n\n");
                }
            }
            else if (num2 > num3)
                Console.Write(num2+" Number is the greatest among three \n\n");
            else
                Console.Write(num3+" Number is the greatest among three \n\n");

        }
    }
}