﻿namespace CSharpPrograms
{
    internal class ReverseWord
    {
        public static void reverseword()
        {
            Console.WriteLine("Enter a Word:");
            String word=Console.ReadLine();
            String rev = "";
            int len = word.Length - 1;
            while(len >= 0)
            {
                rev += word[len];
                len--;
            }
            Console.WriteLine("Reversed String is {0}", rev);
            Console.ReadLine();
        }
    }
}