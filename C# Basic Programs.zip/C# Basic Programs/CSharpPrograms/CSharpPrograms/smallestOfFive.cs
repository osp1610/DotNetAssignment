﻿namespace CSharpPrograms
{
    internal class smallestOfFive
    {
        public static void SmallNo()
        {
            int min = 0;
            Console.Write("Enter five numbers: ");

            for (int i = 0; i < 5; i++)
            {
                int res = Convert.ToInt32(Console.ReadLine());
                if (i == 0)
                {
                    min = res;
                }
                else
                {
                    min = Math.Min(min, res);
                }
            }
            Console.WriteLine("Smallest No is:"+ min);

        }
    }
}