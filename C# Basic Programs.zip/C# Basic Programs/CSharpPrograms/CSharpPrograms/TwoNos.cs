﻿namespace CSharpPrograms
{
    internal class TwoNos
    {
       public static void RangeBetweenTwoNos()
        {
            String firstNo, secondNo;
            int start, end;
            firstNo = Console.ReadLine();
            secondNo = Console.ReadLine();
            start=Convert.ToInt32(firstNo);
            end=Convert.ToInt32(secondNo);
            for(int i = start; i < end; i++)
            {
                Console.WriteLine(i);
            }

        }
    }
}