﻿namespace StringAssignment
{
    internal class StringOperations
    {
       public static void stringOperations()
        {
            String str = "The quick brown fox jumps over the lazy dog";
            Console.WriteLine("A.Print the character at the 12th index: " + str[12]);
            Console.WriteLine("B.Check whether the String contains the word 'is':" + str.Contains("is") );
            String concatString = String.Concat(str, "and killed it");
            Console.WriteLine("C.Add the string “and killed it” to the existing string " + concatString);
            Console.WriteLine("D.Check whether the String ends with the word “dogs”?: " + concatString.EndsWith("dog"));
            Console.WriteLine("E.Check whether the String is equal to “The quick brown Fox jumps over the lazy Dog”. \nCheck whether the String is equal to “THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG”:" +concatString.Equals("The quick brown Fox jumps over the lazy Dog",StringComparison.OrdinalIgnoreCase));
            Console.WriteLine("G.length of the String: " + concatString.Length);
            Console.WriteLine("H.Check whether the String matches to “The quick brown Fox jumps over the lazy Dog” " + concatString.Equals("The quick brown Fox jumps over the lazy Dog"));
            Console.WriteLine("I.Replace the word “The” with the word “A”. "+concatString.Replace("The","A"));
            Console.WriteLine("J.Split the above string into two such that two animal names do not come together. ");
            String[] splitList = concatString.Split("jumps ");
            foreach (String s in splitList) 
            Console.WriteLine(s);
            Console.WriteLine("K.Print the animal names alone separately from the above string: "+concatString.Substring(16,3)+"\n"+concatString.Substring(40,3));
            Console.WriteLine("L.Print the above string in completely lower case: " + concatString.ToLower());
            Console.WriteLine("M.Print the above string in completely upper case: " + concatString.ToUpper());
            Console.WriteLine("N.Find the index position of the character “a”: " +concatString.IndexOf("a"));
            Console.WriteLine("O.Find the last index position of the character “e”: " + concatString.LastIndexOf("e"));
            String sts5 = @"WebApps/MyApps/Images";
            String sts6 = @"/osp";
            Console.WriteLine("P.Adding path to the existing path" + " " + sts5 + ":" + sts5 + sts6);
            Console.WriteLine("Q.saperating the two animals into two different strings:");
            String poem = "I WANDER'D lonely as a cloud That floats on high o'er vales and hills, When all at once I saw a crowd,A host, of golden daffodils; Beside the lake, beneath the trees, Fluttering and dancing in the breeze.";
            String[] splitList1 = poem.Split(", ");
            foreach (String s1 in splitList1)
                Console.WriteLine(s1);

        }

    }
}