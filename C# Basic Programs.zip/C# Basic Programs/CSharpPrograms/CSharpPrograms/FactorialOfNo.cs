﻿namespace CSharpPrograms
{
    internal class FactorialOfNo
    {
       public static void FactOfNumber()
        {
            int fact = 1;
            Console.WriteLine("Enter a number to find factorial");
            String endNo = Console.ReadLine();
            int no=Convert.ToInt32(endNo);
            for (int i = 1; i <= no; i++)
            {
                fact = fact * i;
            }
            Console.WriteLine("Factorial of "+no+" is "+fact);

        }
    }
}