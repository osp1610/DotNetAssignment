﻿using System.Collections;

namespace CollectiionAssignment

{
    internal class employeeDesignation
    {
        static ArrayList allEmpDetails = new ArrayList();
        //static ArrayList allDesg = new ArrayList();
        static ArrayList resultList=new ArrayList();
        static string empName,empDesg;
        static int count;
        static int proMCount=0, PMCount=0, TLCount=0, SPCount=0, JPCount = 0;
        public static void addEmployee()
        {
            Console.WriteLine("Enter a No of employee name you want to enter:");
            count= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a "+count+ " employee Name and designation");
            for(int i = 0; i < count; i++)
            {
                empName = Console.ReadLine();
                empDesg = Console.ReadLine();
                allEmpDetails.Add(empDesg);
                allEmpDetails.Add(empName);
            }
            seprateEmp();
            //displayEmp();
                
        }

        public static void seprateEmp()
        {
            foreach(string s in allEmpDetails)
            {

            }
            

            displayEmp();
        }
      /*  public static void seprateEmp()
        {
            foreach(string empDesg in allDesg)
            {
                if (empDesg.Contains("Program Manager", StringComparison.OrdinalIgnoreCase))
                {
                    proMCount++;
                }
                if (empDesg.Contains("Project Manager", StringComparison.OrdinalIgnoreCase))
                {
                    PMCount++;
                }
                if (empDesg.Contains("Team Lead", StringComparison.OrdinalIgnoreCase))
                {
                    TLCount++;
                }
                if (empDesg.Contains("Senior Programmer", StringComparison.OrdinalIgnoreCase))
                {
                    SPCount++;
                }
                if (empDesg.Contains("Junior Programmer", StringComparison.OrdinalIgnoreCase))
                {
                    JPCount++;
                }
            }
            if (proMCount > 0)
            {
                for(int i = 0; i < proMCount; i++)
                {
                    resultList.Add("Program Manager");
                    resultList.Add(allName[i]);
                    allName.Remove(allName[i]);
                }
            }
            if (PMCount > 0)
            {
                for (int i = 0; i < PMCount; i++)
                {
                    resultList.Add("Project Manager");
                    resultList.Add(allName[i]);
                    allName.Remove(allName[i]);

                }
            }
            if (TLCount > 0)
            {
                for (int i = 0; i < TLCount; i++)
                {
                    resultList.Add("Team Lead");
                    resultList.Add(allName[i]);
                    allName.Remove(allName[i]);

                }
            }
            if (SPCount > 0)
            {
                for (int i = 0; i < SPCount; i++)
                {
                    resultList.Add("Senior Programmer");
                    resultList.Add(allName[i]);
                    allName.Remove(allName[i]);

                }
            }
            if (PMCount > 0)
            {
                for (int i = 0; i < JPCount; i++)
                {
                    resultList.Add("Junior Programmer");
                    resultList.Add(allName[i]);
                    allName.Remove(allName[i]);

                }
            }
                
                displayEmp();



            //Console.WriteLine(proMCount);
            //Console.WriteLine(PMCount);
            //Console.WriteLine(TLCount);
            //Console.WriteLine(SPCount);
            //Console.WriteLine(JPCount);


        }*/

        public static void displayEmp()
        {
            Console.WriteLine("___________________________");
            for (int i = 0; i < allEmpDetails.Count; i++)
            {
                Console.WriteLine(allEmpDetails[i]);
            }
        }
    }
}