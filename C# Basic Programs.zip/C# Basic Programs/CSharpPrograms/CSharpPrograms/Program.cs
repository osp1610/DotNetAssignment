﻿namespace CSharpPrograms
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //welcomeToCSharp.welcome();
            //TwoNos.RangeBetweenTwoNos();
            //oddOrEvenNo.oddevenNo();
            //totalNoOfOddandEven.TotaloddevenNo();
            //TempFarToCel.FarToCel();
            // PrintSeries.printNoSeries();
            //FactorialOfNo.FactOfNumber();
            // FiboSeriesUpTo40.fiboSeries();
            //MultiplicationOfNo.MultiplicationUpTo20();
            // DivisibleBy7.DivisibleBy7InBet200To300();
            //LargerFromThree.LargestNo();
            //smallestOfFive.SmallNo();
            //Marks.MarksTotalAvgMinMax();
            // WordLength.WordLengthAndDisplay();
            // ReverseWord.reverseword();
            //CompareWord.compareTwoWords();
            Palindrome.PalindromeOrNot();
        }
    }
}