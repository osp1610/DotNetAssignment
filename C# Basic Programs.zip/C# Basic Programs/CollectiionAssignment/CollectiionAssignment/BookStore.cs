﻿using System.Collections;

namespace CollectiionAssignment

{
    
    internal class BookStore
    {
        static int bookId;
        static string bookName;
        static Hashtable hashtable = new Hashtable();
        static int count;
        static public void acceptBook()
        {
            Console.WriteLine("Enter a No of books you want to add:");
            count = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a " + count + " Book Id and Book Name");

            for (int i = 0; i < count; i++)
            {
                bookId = Convert.ToInt32(Console.ReadLine());
                bookName = Console.ReadLine();
                hashtable.Add(bookId, bookName);
            }
            displayBook();
        }
        static public void displayBook()
        {
            Console.WriteLine("Books Details:");
            foreach(DictionaryEntry de in hashtable)
            {
                Console.WriteLine("Book Id:"+de.Key + " & Book Name:" + de.Value);
            }
        }
        

    }
}
