﻿namespace StringAssignment
{
    internal class leapYear
    {
       public static void leapYearorNot()
        {
            Console.WriteLine("Enter a Year to check it is leap or not");
            long year = Convert.ToInt64(Console.ReadLine());
            if ((year % 400) == 0)
                Console.WriteLine("{0} is a leap year.\n", year);
            else if ((year % 100) == 0)
                Console.WriteLine("{0} is not a leap year.\n", year);
            else if ((year % 4) == 0)
                Console.WriteLine("{0} is a leap year.\n", year);
            else
                Console.WriteLine("{0} is not a leap year.\n", year);
        }

    }
}