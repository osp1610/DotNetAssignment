﻿namespace CSharpPrograms
{
    internal class welcomeToCSharp
    {
       public static void welcome()
        {
            Console.WriteLine("Hello, World!");
            Console.ReadKey();
        }
    }
}