﻿namespace CSharpPrograms
{
    internal class totalNoOfOddandEven
    {
        public static void TotaloddevenNo()
        {
            String Number,Range;
            int no, range, oddcount = 0,evencount=0 ;
            Console.WriteLine("Enter a Range to count even and odd nos");
            Range = Console.ReadLine();
            range=Convert.ToInt32(Range);
            Console.WriteLine("Enter a Numbers");

            for(int i=0;i<range;i++)
            {
            Number=Console.ReadLine();
            no=Convert.ToInt32(Number);
                if (no % 2 == 0)
                {
                    evencount++;
                }
                else
                {
                    oddcount++;
                }
            }
           
            Console.WriteLine("Even No Count "+evencount);
            Console.WriteLine("Odd No Count "+oddcount);

        }
    }
}