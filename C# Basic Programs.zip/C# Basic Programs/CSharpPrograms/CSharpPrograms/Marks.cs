﻿namespace CSharpPrograms
{
    internal class Marks
    {
        public static void MarksTotalAvgMinMax()
        {
            int min = 0,max=0,Total=0,Avg=0;

            Console.Write("Enter Marks of 10 Subjects: ");

            for (int i = 0; i < 10; i++)
            {
                int res = Convert.ToInt32(Console.ReadLine());
                Total=Total+res;
                Avg = Total / 10 ;
                if (i == 0)
                {
                    min =max= res;
                }
                else
                {
                    max=Math.Max(max,res);
                    min = Math.Min(min, res);
                }
            }
            Console.WriteLine("Total Marks of All Subject:" + Total);
            Console.WriteLine("Average Marks of all subjects" + Avg);
            Console.WriteLine("Maximum Marks" + max);
            Console.WriteLine("Minimum Marks:"+ min);

        }
    }
}