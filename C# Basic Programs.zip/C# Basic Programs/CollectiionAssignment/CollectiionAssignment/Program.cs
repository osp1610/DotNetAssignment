﻿
namespace CollectiionAssignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //sortList.sortlist();
            //arraylistStudent.arrayListForStudent();
            //employeeCode.employeeNameandCode();
            //BookStore.acceptBook();
            employeeDesignation.addEmployee();
        }
    }
}