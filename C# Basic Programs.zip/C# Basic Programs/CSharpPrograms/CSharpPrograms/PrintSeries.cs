﻿namespace CSharpPrograms
{
    internal class PrintSeries
    {
       public static void printNoSeries()
        {
            Console.WriteLine("Enter a number up to you want to print series");
            String endNo = Console.ReadLine();
            int no=Convert.ToInt32(endNo);
            for(int i = 0; i <= no; i++)
            {
                int result = i * i;
                Console.WriteLine(result);
            }

        }
    }
}