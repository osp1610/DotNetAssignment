﻿using System.Collections;
namespace CollectiionAssignment
{
    internal class employeeCode
    {
        //static Dictionary<string, string> d = new Dictionary<string, string>();
       //static Hashtable hashtable= new Hashtable();
       static SortedList sortedList=new SortedList();
        static string empCode, empNames;
        static int count;
        public static void employeeNameandCode()
        {
            Console.WriteLine("Enter a No of Employee name and code you want to enter:");
            count = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a " + count + " Employee Code and Name");

            for(int i = 0; i < count; i++)
            {
                empCode = Console.ReadLine();
                empNames = Console.ReadLine();
                sortedList.Add(empCode, empNames);
            }
            
            Console.WriteLine( "Data of employees:");
            var key=sortedList.Keys;

            foreach (string k in key)
            {
                Console.WriteLine(k + ": " + sortedList[k]);
            }
        }
    }
}