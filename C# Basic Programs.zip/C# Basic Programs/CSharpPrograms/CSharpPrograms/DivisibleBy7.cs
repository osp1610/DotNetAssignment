﻿namespace CSharpPrograms
{
    internal class DivisibleBy7
    {
       public static void DivisibleBy7InBet200To300()
        {
            for(int i = 200; i < 301; i++)
            {
                if (i % 7 == 0)
                {
                    Console.WriteLine(i);
                }
                
            }

        }
    }
}