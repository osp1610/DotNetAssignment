﻿namespace CSharpPrograms
{
    internal class TempFarToCel
    {
         public static void FarToCel()
        {
            String Far, Cel;
            Double TempFar, TempCel;
            Console.WriteLine("Enter a temperature");
            Far = Console.ReadLine();
            TempFar = Convert.ToDouble(Far);
            TempCel = (TempFar - 32) * 5 / 9;
            Console.WriteLine("temperature in celsius " + TempCel);
        }
    }
}