﻿namespace CSharpPrograms
{
    internal class FiboSeriesUpTo40
    {
       public static void fiboSeries()
        {
            int n1 = 0, n2 = 1, n3;
            Console.Write(n1+"\n") ;    
            Console.Write(n2+"\n") ;
            for (int i = 2; i <= 40; i++)   
            {
                n3 = n1 + n2;
                Console.Write(n3+"\n");
                n1 = n2;
                n2 = n3;
            }
        }
    }
}