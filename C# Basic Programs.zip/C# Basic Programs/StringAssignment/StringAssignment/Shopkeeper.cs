﻿namespace StringAssignment
{
    internal class Shopkeeper
    {
       public static void ProductSells()
        {
            double sum = 0;
            double n1 = 22.5D, n2 = 44.50D, n3 = 9.98D;
            for (int i = 0; i < 3; i++)
            {
                Console.Write("Enter product code or number:");
                double a = double.Parse(Console.ReadLine());
                Console.Write("Enter Product Quantity:");
                double b=double.Parse(Console.ReadLine());
                
                switch (i)
                {
                    case 1:
                        sum = (sum + (n1 * b));
                        break;
                    case 2:
                        sum = (sum + (n2 * b));
                        break;
                    case 3:
                        sum = (sum + (n3 * b));
                        break;
                }
            }
            Console.WriteLine(sum);

        }

    }
}