﻿namespace CSharpPrograms
{
    internal class WordLength
    {
        public static void WordLengthAndDisplay()
        {
            Console.WriteLine("Enter a Word:");
            String word=Console.ReadLine();
            int length = word.Length;
            Console.WriteLine("Word " + word + "\nLength " + length);
        }
    }
}